package model;

public class Fresher extends Candidate {
    private int graduationDate;
    private String graduationRank;
    public Fresher() {
        super();
    }

    public Fresher(String id,
                   String firstName, String lastName, int birthDate, String address,
                   String phone, String email, int typeCandidate,int graduationDate, String graduationRank) {
        super(id,firstName,lastName,birthDate,address,phone,email,typeCandidate);
        this.graduationDate = graduationDate;
        this.graduationRank = graduationRank;
    }

    public int getGraduationDate() {
        return graduationDate;
    }

    public void setGraduationDate(int graduationDate) {
        this.graduationDate = graduationDate;
    }

    public String getGraduationRank() {
        return graduationRank;
    }

    public void setGraduationRank(String graduationRank) {
        this.graduationRank = graduationRank;
    }
    public String toString() {
        return super.toString() + String.format("%-25s %-15s",this.graduationDate, this.graduationRank);
}
}
