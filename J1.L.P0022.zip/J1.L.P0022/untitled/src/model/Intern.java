package model;

public class Intern extends Candidate {
    private String major;
    private int semester;
    private String university;

    public Intern() {
        super();
    }

    public Intern(
                  String id, String firstName, String lastName, int birthDate,
                  String address, String phone, String email, int typeCandidate,String major, int semester, String university) {
        super(id, firstName, lastName, birthDate, address, phone, email,
                typeCandidate);
        this.major = major;
        this.semester = semester;
        this.university = university;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String toString() {
        return super.toString() + String.format("%-25s %-15s %-15s", this.major, this.semester, this.university);
    }
}