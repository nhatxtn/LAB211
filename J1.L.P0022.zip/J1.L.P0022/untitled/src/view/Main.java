package view;

import controller.Manager;
import model.Candidate;

import java.util.ArrayList;

public class Main extends Menu<String>{
    ArrayList<Candidate> candidateList = new ArrayList<>();
    static String[] menu = {"Create Experience","Create Fresher","Create Intern","Searching","Add Data", "Exit"};
    public Manager manager = new Manager();
    public Main(){ super("Candidate Management", menu);
    }
    @Override
    public void execute(int n){
        switch (n){
            case 1:
                Manager.createCandidate(candidateList, 0);
                break;
            case 2:
                Manager.createCandidate(candidateList, 1);
                break;
            case 3:
                Manager.createCandidate(candidateList, 2);
                break;
            case 4:
                Manager.searchCandidate(candidateList);
                break;
            case 5:
                Manager.addData(candidateList);
                break;
            case 6:
                System.exit(1);
        }
    }

    public static void main(String[] args) {
        Main main = new Main();
        main.run();
    }
}
