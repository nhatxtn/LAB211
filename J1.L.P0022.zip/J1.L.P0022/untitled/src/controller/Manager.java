package controller;

import model.Candidate;
import model.Experience;
import model.Fresher;
import model.Intern;
import view.Validation;

import java.util.ArrayList;
import java.util.Calendar;

public class Manager {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";

    public static void createCandidate(ArrayList<Candidate> candidateList, int type) {
        while (true) {
            System.out.println("Enter Id: ");
            String id = Validation.checkInputString();
            System.out.println("Enter first name: ");
            String firstName = Validation.checkInputString();
            System.out.println("Enter last name: ");
            String lastName = Validation.checkInputString();
            System.out.println("Enter birth year: ");
            int birthDate = Validation.checkInputIntLimit(1900, Calendar.getInstance().get(Calendar.YEAR));
            System.out.println("Enter address: ");
            String address = Validation.checkInputString();
            System.out.println("Enter phone: ");
            String phone = Validation.checkInputPhone();
            System.out.println("Enter email: ");
            String email = Validation.checkInputEmail();
            Candidate candidate = new Candidate(id, firstName, lastName,
                    birthDate, address, phone, email, type);
            if (Validation.checkIdExist(candidateList, id)) {
                switch (type) {
                    case 0:
                        createExperience(candidateList, candidate);
                        break;
                    case 1:
                        createFresher(candidateList, candidate);
                        break;
                    case 2:
                        createIntern(candidateList, candidate);
                        break;
                }
            } else {
                return;
            }
            System.out.print("Do you want to continue (Y/N): ");
            if (!Validation.checkInputYN()) {
                printList(candidateList);
                return;
            }
        }

    }

    public static void createExperience(ArrayList<Candidate> candidateList,
                                        Candidate candidate) {
        System.out.print("Enter year of experience: ");
        int yearExperience = Validation.checkInputExprience(candidate.getBirthDate());
        System.out.print("Enter professional skill: ");
        String proSkill = Validation.checkInputString();
        candidateList.add(new Experience(
                candidate.getId(), candidate.getFirstName(), candidate.getLastName(),
                candidate.getBirthDate(), candidate.getAddress(),
                candidate.getPhone(), candidate.getEmail(), candidate.getTypeCandidate(),yearExperience, proSkill));
        System.out.println("Create success.");
    }

    public static void createFresher(ArrayList<Candidate> candidateList, Candidate candidate) {
        System.out.println("Enter graduated time: ");
        int graDay = Validation.checkInputIntLimit(1990, Calendar.getInstance().get(Calendar.YEAR));


        System.out.print("Enter graduation rank: ");
        String graduationRank = Validation.checkInputString();
        candidateList.add(new Fresher(candidate.getId(), candidate.getFirstName(), candidate.getLastName(),
                candidate.getBirthDate(), candidate.getAddress(),
                candidate.getPhone(), candidate.getEmail(), candidate.getTypeCandidate(),graDay, graduationRank));
        System.out.println("Create success.");
    }

    public static void createIntern(ArrayList<Candidate> candidateList,
                                    Candidate candidate) {
        System.out.print("Enter major: ");
        String major = Validation.checkInputString();
        System.out.print("Enter semester: ");
        int semester = Validation.checkInputIntLimit(1,9);
        System.out.print("Enter university: ");
        String university = Validation.checkInputString();
        candidateList.add(new Intern(candidate.getId(),
                candidate.getFirstName(), candidate.getLastName(),
                candidate.getBirthDate(), candidate.getAddress(),
                candidate.getPhone(), candidate.getEmail(),
                candidate.getTypeCandidate(),major, semester, university));
        System.out.println("Create success.");
    }

    public static void searchCandidate(ArrayList<Candidate> candidateList) {
        printList(candidateList);
        System.out.println("Enter first name or last name to search: ");
        String nameSearch = Validation.checkInputString();
        System.out.println("Enter type of candidate to search: ");
        int typeCandidate = Validation.checkInputIntLimit(0, 2);
        for (Candidate candidate : candidateList) {
            if (candidate.getTypeCandidate() == typeCandidate && candidate.getLastName().equalsIgnoreCase(nameSearch) || candidate.getFirstName().equalsIgnoreCase(nameSearch)) {
                if (candidate instanceof Experience)
                    System.out.println(candidate);
                else if (candidate instanceof Fresher)
                    System.out.println(candidate);
                else System.out.println(candidate);
            }
        }
    }

    public static void addData(ArrayList<Candidate> candidateList) {
        String[] id = {"DE178072", "DE174297", "DE176725", "DE171478", "DE162465", "DS178213",
                "DS164143", "DS166114", "DS175706", "DS168644"};
        String[] firstName = {"Khang", "Tu", "Cuong", "Dung", "Thanh", "Van", "My", "Thang", "Loc", "Tai"};
        String[] lastName = {"Quang", "Anh", "Quoc", "Tran", "Cao", "Dang", "Thao", "Ngo", "Nguyen", "Ha"};

    String[] phone = {"0912853245","0364354245","0123457879","0949215212","0905719811","0254888490","0422244433","0321342233","0762849333","0333748922"};
    int[] birthDay = {1990, 1991, 2002, 2003, 2005, 2006, 2005, 2006, 2012, 2014};
    String[] address = {"Da Nang", "Da Nang", "Quang Ngai", "Quang Nam", "Da Nang", "Da Nang", "Hue"
            , "Quang Tri", "Da Nang", "Da Nang"};
    String[] email = {"keenan.murphy@gmail.com", "kaylin19@gmail.com",
            "alisha.collier@gmail.com", "krista.lang@gmail.com", "nnicolas@gmail.net",
            "leannon.rae@gmail.com",
            "georgiana74@gmail.com",
            "alene.robel@gmail.com",
            "egleason@gmail.com",
            "zemlak.alayna@gmail.com"};
    int[] graDate = {0,0,2010,2011,2020,2021};
    int[] yearExp= {4,3};
    String[] proSkill = {"Java","Css"};
    String[] graRank ={null, null, "Good", "Fair","Poor","Excellent"};
    String[] major ={null,null,null,null,null,null, "SE","BA","FE","CS"};
    int[] semester={0,0,0,0,0,0,1,2,3,7};
    int[] type = {0, 0, 1, 1, 1, 1, 2, 2, 2, 2};
    String[] uni = {null,null,null,null,null,null, "FPT","DUT","DUE","Oxford"};
        for (int i = 0; i < 2; i++) {
            Candidate c1 = new Experience(id[i],firstName[i],lastName[i],birthDay[i],address[i],phone[i],email[i],type[i],yearExp[i],proSkill[i] );
            candidateList.add(c1);
        }
        for (int i = 2; i < 6; i++){
            Candidate c2 = new Fresher(id[i], firstName[i],lastName[i],birthDay[i],address[i],phone[i],email[i],type[i],graDate[i],graRank[i]);
            candidateList.add(c2);
        }
        for (int i = 6; i < 10; i++){
            Candidate c3 = new Intern(id[i], firstName[i],lastName[i],birthDay[i],address[i],phone[i],email[i],type[i],major[i], semester[i],uni[i]);
            candidateList.add(c3);
        }
        System.out.println("Add successful!!");

};

        public static void printList(ArrayList<Candidate> candidateList){
            System.out.println(ANSI_GREEN+ "EXPERIENCE CANDIDATE" + ANSI_RESET);
            System.out.printf("%-20s %-20s %-15s %-15s %-15s %-15s %-30s %-19s %-25s %-15s\n", "ID", "FirstName", "LastName", "BirthDate", "Address", "Phone", "Email","Type Candidate","Experience year", "Professional SKill");
            for (Candidate candidate : candidateList) {
                if (candidate instanceof Experience) {
                    System.out.println(candidate);
                }
            }
                System.out.println(ANSI_RED+ "FRESHER CANDIDATE" + ANSI_RESET);
            System.out.printf("%-20s %-20s %-15s %-15s %-15s %-15s %-30s %-19s %-25s %-15s\n", "ID", "FirstName", "LastName", "BirthDate", "Address", "Phone", "Email","Type Candidate","Graduation Year", "Graduation Rank");
            for (Candidate candidate : candidateList) {
                if (candidate instanceof Fresher) {
                    System.out.println(candidate);
                }
            }
                System.out.println(ANSI_YELLOW+ "INTERN CANDIDATE" + ANSI_RESET);
                System.out.printf("%-20s %-20s %-15s %-15s %-15s %-15s %-30s %-19s %-25s %-15s %-15s\n", "ID", "FirstName", "LastName", "BirthDate", "Address", "Phone", "Email","Type Candidate","Major", "Semester","University");
            for (Candidate candidate : candidateList) {
                if (candidate instanceof Intern) {
                    System.out.println(candidate);
                }
            }
        }
    }



