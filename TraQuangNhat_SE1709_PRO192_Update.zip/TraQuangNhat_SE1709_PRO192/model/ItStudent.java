package assignment.model;

import java.util.Scanner;

public class ItStudent extends Student {
	Scanner sc=new Scanner(System.in);
	private double javaScore;
	private double cssScore;
	
	public ItStudent() {
		
	}

	public ItStudent(String iD, String name, Address address, double javaScore, double cssScore) {
		super(iD, name, address);
		this.javaScore = javaScore;
		this.cssScore = cssScore;
	}

	public double getJavaScore() {
		return javaScore;
	}

	public void setJavaScore() {
		while (true){
			if (sc.hasNextDouble()){
				double java_score = sc.nextDouble();
				sc.nextLine();
				if (java_score > 0){
					this.javaScore = java_score;
					break;
				}
				System.err.println("Number is negative or zero - Please try again: ");
				continue;
			}
			System.err.println("Please input number only: ");
			sc.next();
		}
	}

	public void setCssScore() {

		while (true){
			if (sc.hasNextInt()){
				double CSS_score = sc.nextDouble();
				sc.nextLine();
				if (CSS_score > 0){
					this.cssScore = CSS_score;
					break;
				}
				System.err.println("Number is negative or zero - Please try again: ");
				continue;
			}
			System.err.println("Please input number only: ");
			sc.next();
		}
	}

	public double getCssScore() {
		return cssScore;
	}

	@Override
	public double avgScore() {
		return (3 * getJavaScore() +  getCssScore()) / 4;
	}
	
	@Override
	public void inputData() {

		super.inputData();
		System.out.print("Enter student's Java score: ");
		setJavaScore();
		System.out.print("Enter student's Css score: ");
		setCssScore();
		}
	@Override
	public String toString() {
		return super.toString() + String.format(" %-12.2f %-12.2f %-12s %-12s %-12.2f ", javaScore, cssScore, "null", "null", avgScore());
	}

	
}
