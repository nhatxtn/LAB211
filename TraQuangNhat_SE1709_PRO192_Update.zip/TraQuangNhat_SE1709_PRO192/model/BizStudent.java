package assignment.model;

public class BizStudent extends Student {
	private double accountingScore;
	private double marketingScore;
	
	public BizStudent() {
		
	}

	public BizStudent(String iD, String name, Address address , double accountingScore, double marketingScore) {
		super(iD, name, address);
		this.accountingScore = accountingScore;
		this.marketingScore = marketingScore;
	}

	public double getAccountingScore() {
		return accountingScore;
	}

	public void setAccountingScore() {
		while (true){
			if (sc.hasNextDouble()){
				double accounting_score = sc.nextDouble();
				sc.nextLine();
				if (accounting_score > 0){
					this.accountingScore = accounting_score;
					break;
				}
				System.err.println("Number is negative or zero - Please try again: ");
				continue;
			}
			System.err.println("Please input number only: ");
			sc.next();
		}
	}


	public void setMarketingScore() {
		while (true){
			if (sc.hasNextDouble()){
				double marketing_score = sc.nextDouble();
				sc.nextLine();
				if (marketing_score > 0){
					this.marketingScore = marketing_score;
					break;
				}
				System.err.println("Number is negative or zero - Please try again: ");
				continue;
			}
			System.err.println("Please input number only: ");
			sc.next();
		}
	}

	public double getMarketingScore() {
		return marketingScore;
	}

	@Override
	public double avgScore() {
		return (getAccountingScore() * 2 + getMarketingScore()) / 3;
	}
	@Override
	public void inputData() {
		super.inputData();
		System.out.print("Enter student's Accounting score: ");
		setAccountingScore();
		System.out.print("Enter student's Marketing score: ");
		setMarketingScore();
	}
	
	@Override
	public String toString() {
		return super.toString() + String.format(" %-12s %-12s %-12.2f %-12.2f %-12.2f", "null", "null", accountingScore, marketingScore, avgScore());
	}
}
