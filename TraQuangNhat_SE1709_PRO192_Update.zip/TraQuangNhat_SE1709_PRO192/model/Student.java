package assignment.model;

import assignment.view.CheckInfo;

import java.util.Scanner;
import java.util.regex.Pattern;

public abstract class Student {
	private String iD;
	private String name;
	private Address address;


	Scanner sc = new Scanner(System.in);
	
	public Student() {
		
	}
	public abstract double avgScore();
	public Student(String iD, String name, Address address) {
		this.iD = iD;
		this.name = name;
		this.address = address;


	}

	public String getiD() {
		return iD;
	}

	public void setiD(String iD) {
		this.iD = iD;
	}

	public String getName() {
		return name;
	}


	public String getAddress() {
		return address.toString();
	}


	public void setName() {
		while (true) {
			String full_name = sc.nextLine();
			if (Pattern.matches(CheckInfo.checkFullName, full_name)) {
				this.name = full_name;
				break;
			} else {
				System.err.println("Wrong format!!! - Please try again");
			}
		}
	}


	public void setAddress(String city) {
		while (true) {
			 city = sc.nextLine();
			if (Pattern.matches(CheckInfo.CheckAddress, city)) {
				setAddress(city);
				break;
			} else {
				System.err.println("Wrong format!!! - Please try again");
			}
		}
	}
	public void inputData() {
		System.out.print("Enter student's ID: ");
		iD = sc.nextLine();
		System.out.print("Enter student's name: ");
		setName();
		System.out.print("Enter student's address (City) : ");
		setAddress(address.city);

	}
	
	public String toString() {
		return String.format("%-20s %-20s %-15s ", iD, name, address);
	}



	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
