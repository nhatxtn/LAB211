package assignment.view;

public interface CheckInfo {
    String checkFullName = "^([a-zA-Z]{1,}\s[a-zA-Z]{1,}'?-?[a-zA-Z]{1,}\s?([a-zA-Z]{1,})?)";

    String CheckAddress = "([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)";
}
