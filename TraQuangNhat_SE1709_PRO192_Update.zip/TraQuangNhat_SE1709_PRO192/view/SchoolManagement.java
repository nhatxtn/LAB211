package assignment.view;

import assignment.controller.School;
import assignment.model.ItStudent;
import assignment.model.Student;

public class SchoolManagement extends Menu<String> {
				Student s1 = new ItStudent();

				static String[] menu={"Add data","Input new student","Print the student list","Sort student list (by Name)","Count and print out the number of students in the same city of 2 faculties","Search student (by ID) and Update or Delete","Report","Exit"  };
				private School school=new School();
				public SchoolManagement(){
					super("School Management System",menu);
				}
				@Override
				public void execute(int n){
					switch (n){
						case 1:
							School.addData();
							break;
						case 2:
							School.inputStudent();
							break;
						case 3:
							School.printStudentList();
							break;
						case 4:
							School.sortStudent();
							break;
						case 5:
							School.countAndPrint();
							break;
						case 6:
							School.searchStudent();
							break;
						case 7:
							School.report();
							break;
						case 8:
							System.exit(1);
					}
				}

				public static void main(String[] args) {
					SchoolManagement school=new SchoolManagement();
					school.run();
				}
			}

