package assignment.controller;

import assignment.model.Address;
import assignment.model.BizStudent;
import assignment.model.ItStudent;
import assignment.model.Student;

import java.util.*;

public class School {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Student> listStudent = new ArrayList<>();
    static Random r = new Random();

    public static void inputStudent() {
        String exitChoice;

            try {
                do {
                    System.out.println("New student? (1 = IT, 2 = Biz)");
                int studentChoice = Integer.parseInt(sc.nextLine());
                if (studentChoice > 2 || studentChoice <= 0){
                    System.out.println("Input from 1 to 2: ");
                    inputStudent();
                }
                if (studentChoice == 1) {
                    Student stIT = new ItStudent();
                    stIT.inputData();
                    listStudent.add(stIT);
                }
                if (studentChoice == 2) {
                    Student stBiz = new BizStudent();
                    stBiz.inputData();
                    listStudent.add(stBiz);
                }
                    if (studentChoice == 3) {
                        Student stBiz = new Student() {
                            @Override
                            public double avgScore() {
                                return 0;
                            }
                        };
                        stBiz.inputData();
                        listStudent.add(stBiz);
                    }

                    System.out.println("Input next student? [Y/N]");
                    exitChoice = sc.nextLine();
                    if (exitChoice.toUpperCase().equals("N")) {
                        System.out.println("Inputting completed!");
                    }
                } while (exitChoice.toUpperCase().equals("Y"));
            }  catch (NumberFormatException e){
                System.out.println("Wrong input. Input from 1 to 2: ");
               inputStudent();
            }
    }

    public static void printStudentList() {
        System.out.printf("%-20s %-20s %-15s %-12s %-12s %-12s %-12s %-12s\n", "ID", "Name", "Address",
                 "Java Score", "CSS Score", "Acc. Score", "Mar. Score", "Avg. Score");
        for (Student item : listStudent) {
            System.out.println(item);
        }
    }

    public static void searchStudent() {
        String addressKey;
        System.out.print("Enter the student's ID to search: ");
        addressKey = sc.nextLine().trim();
        if (!listStudent.isEmpty()  ) {
            System.out.printf("%-20s %-20s %-15s %-12s %-12s %-12s %-12s %-12s\n", "ID", "Name", "Address",
                    "Java Score", "CSS Score", "Acc. Score", "Mar. Score", "Avg. Score");
            for (Student value : listStudent) {
                if (addressKey.equals(value.getiD())) {
                    System.out.println(value);
                } else {
                    System.out.println("No students matches!!");
                    return;
                }
            }
            System.out.println("Do you want to update (U) or delete (D) student?");
            try {

                String updateChoice = (sc.nextLine());
                if (updateChoice.toUpperCase().equals("U")) {
                    updateStudent();
                }
                if (updateChoice.toUpperCase().equals("D")) {
                    removeStudent();
                }

            } catch (NumberFormatException e) {
                System.out.println("Wrong input. Input U or D: ");
                searchStudent();
            }
        } else {
            System.out.println("No students were found!!");
            return;
        }
    }

    public static void removeStudent() {
        System.out.print("Enter the student's ID to remove: ");
        String iDKey = sc.nextLine();
        for (int i = 0; i < listStudent.size(); i++) {
            if (iDKey.equals(listStudent.get(i).getiD())) {
                listStudent.remove(i);
                System.out.println("Student removed successful!!!");
            }
        }
    }
    public static void countAndPrint() {
        if (listStudent.isEmpty()) {
            System.out.println("The list is empty!");
            return;
        }
        Map<String, Integer> cityAndCountIT = new HashMap<>();
        Map<String, Integer> cityAndCountBiz = new HashMap<>();

        // build hash table for IT
        for (Student std : listStudent) {
            // check duplicate city for faculty IT
            if (std instanceof ItStudent) {
                Integer count1 = cityAndCountIT.get(((ItStudent) std).getAddress());
                if (count1 == null) {
                    cityAndCountIT.put(((ItStudent) std).getAddress(), 1);
                } else {
                    cityAndCountIT.put(((ItStudent) std).getAddress(), ++count1);
                }
            }

        }

        // build hash table for Biz
        for (Student std : listStudent) {
            // check duplicate city for faculty Biz
            if (std instanceof BizStudent) {
                Integer count2 = cityAndCountBiz.get(((BizStudent) std).getAddress());
                if (count2 == null) {
                    cityAndCountBiz.put(((BizStudent) std).getAddress(), 1);
                } else {
                    cityAndCountBiz.put(((BizStudent) std).getAddress(), ++count2);
                }
            }
        }
        // print same city for each faculty
        Set<Map.Entry<String, Integer>> entrySetIT = cityAndCountIT.entrySet();
        Set<Map.Entry<String, Integer>> entrySetBiz = cityAndCountBiz.entrySet();
        for (Map.Entry<String, Integer> entryIT : entrySetIT) {
            System.out.println("There are " + entryIT.getValue() + " IT student(s) in " + entryIT.getKey());
        }
        for (Map.Entry<String, Integer> entryBiz : entrySetBiz) {
            System.out.println("There are " + entryBiz.getValue() + " Biz student(s) in " + entryBiz.getKey());
        }
    }

    public static void updateStudent() {
        System.out.print("Enter the student's ID to update: ");
        String iDKey = sc.nextLine();
        for (Student student : listStudent) {
            if (iDKey.equals(student.getiD())) {
                System.out.print("Update student's name: ");
                student.setName();
                System.out.print("Update student's address: ");
                student.setAddress(sc.nextLine());

                if (student instanceof ItStudent) {
                    System.out.print("Update Java Score: ");
                    ((ItStudent) student).setJavaScore();
                    System.out.print("Update CSS Score: ");
                    ((ItStudent) student).setCssScore();
                }
                if (student instanceof BizStudent) {
                    System.out.print("Update Accounting Score: ");
                    ((BizStudent) student).setAccountingScore();
                    System.out.print("Update Marketing Score: ");
                    ((BizStudent) student).setMarketingScore();
                }
                System.out.println("Student updated!");
            } else {
                System.out.println("Student is not avalable!");
            }
        }

    }

    public static void sortStudent() {
        listStudent.sort(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getName().compareTo(o2.getName());
            }

        });
        System.out.println("Student list sorted!");
    }
    public static void report(){
        System.out.println("----------------------------");
        System.out.println("List of passed IT students: ");
       listStudent.stream().filter(p -> p instanceof ItStudent).filter(p -> ((ItStudent)(p)).avgScore()>4).forEach(System.out::print);
        System.out.println();
        System.out.println("List of passed BizT students: ");
        listStudent.stream().filter(p -> p instanceof BizStudent).filter(p -> ((BizStudent)(p)).avgScore()>4).forEach(System.out::print);
        System.out.println();
        System.out.println("----------------------------");

    }

    public static void printInterval(){
        try {
            System.out.print("Enter the lower bound of the Score interval: ");
            Double lowerBound = Double.parseDouble(sc.nextLine());
            System.out.print("Enter the upper bound of the Score interval: ");
            Double upperBound = Double.parseDouble(sc.nextLine());

        System.out.printf("%-20s %-20s %-15s %-12s %-12s %-12s %-12s %-12s\n", "ID", "Name", "Address",
                 "Java Score", "CSS Score", "Acc. Score", "Mar. Score", "Avg. Score");
        for (Student student : listStudent) {
            if (student instanceof ItStudent) {
                if (((ItStudent) student).avgScore() <= upperBound
                        && lowerBound <= ((ItStudent) student).avgScore()) {
                    System.out.println(student);
                }
            }
            if (student instanceof BizStudent) {
                if (((BizStudent) student).avgScore() <= upperBound
                        && lowerBound <= ((BizStudent) student).avgScore()) {
                    System.out.println(student);
                }
            }
        }
        } catch (NumberFormatException e){
            System.out.println("Input number only!!!");
            printInterval();
        }
    }
    public static void printHighestScore(){
        System.out.printf("%-20s %-20s %-15s %-12s %-12s %-12s %-12s %-12s\n", "ID", "Name", "Address",
                 "Java Score", "CSS Score", "Acc. Score", "Mar. Score", "Avg. Score");
        for (Student student : listStudent) {
            if (student instanceof ItStudent) {
                student.avgScore();
            }
            if (student instanceof BizStudent) {
                student.avgScore();
            }

        }
        listStudent.sort(new Comparator<Student>() {

            @Override
            public int compare(Student o1, Student o2) {
                return Double.compare(o2.avgScore(), o1.avgScore());
            }

        });
        try {
            for (int i = 0; i < 5; i++) {
                System.out.println(listStudent.get(i));
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("List ended! Can't print more students!");
        }
    }
    /* public static void exportFile(){
         try {
             FileWriter writer = new FileWriter("ListStudent.txt");
             writer.write(String.format("%-20s %-20s %-15s %-12s %-12s %-12s %-12s %-12s\n", "ID", "Name",
                     "Address",  "Java Score", "CSS Score", "Acc. Score", "Mar. Score", "Avg. Score"));
             for (Student std : listStudent) {
                 writer.write(std + System.lineSeparator());

             }
             System.out.println("File completely exported!");
             writer.close();
         } catch (IOException e) {
             System.out.println("File exported unsuccessful!");
             e.printStackTrace();
         }

     }
     public static void importFile(){
         try {

             BufferedReader bufReader = new BufferedReader(new FileReader("ListStudent.txt"));
             String line = bufReader.readLine();
             while (line != null) {
                 StringTokenizer data = new StringTokenizer(line," ");
                 String[] arr = new String[data.countTokens()];

                 for (int i = 0; i < arr.length; i++) {
                     arr[i] = data.nextToken();
                 }
                 if (arr[6].equals("null")) {
                     Student s1 = new IT(arr[0], arr[1], arr[2], arr[3], Double.parseDouble(arr[4]), Double.parseDouble(arr[5]), Double.parseDouble(arr[8]));
                     listStudent.add(s1);
                 }
                 if (arr[4].equals("null")) {
                     Student s1 = new Biz(arr[0], arr[1], arr[2], arr[3], Double.parseDouble(arr[6]), Double.parseDouble(arr[7]), Double.parseDouble(arr[8]));
                     listStudent.add(s1);
                 }
                 line = bufReader.readLine();
             }
             bufReader.close();
             System.out.println("Import successful!");

         } catch (IOException e){
             e.printStackTrace();
         }
     }*/
    public static void addData(){
        String[] id = { "DE178072", "DE174297", "DE176725", "DE171478", "DE162465", "DS178213",
                "DS164143", "DS166114" ,"DS175706","DS168644" };
        String[] name = { "Quang Nhat", "Anh Tu", "Quoc Cuong",
                "Anh Dung" , "Cao Thanh" , "Ngoc Van" , "Thao My" , "Chien Thang" , "Truong Loc" , "Thanh Tai" };
        String[] cityAddress= { "Da Nang" , "Da Nang" , "Quang Ngai" , "Quang Nam" , "Da Nang" , "Da Nang" , "Hue"
                , "Quang Tri" , "Da Nang" , "Da Nang" };
        ArrayList<Address> listAddress = new ArrayList<Address>();
        for (int i = 0; i < 10; i++) {
            listAddress.add(new Address(cityAddress[i]));
        }
        for (int i = 0; i < 5; i++) {
            Student s1 = new ItStudent(id[i] , name[i] , listAddress.get(i) , r.nextDouble(0,10), r.nextDouble(0,10));
            listStudent.add(s1);
        }
        for (int i = 5; i < 10; i++) {
            Student s2 = new BizStudent(id[i] , name[i] , listAddress.get(i) , r.nextDouble(0,10), r.nextDouble(0,10));
            listStudent.add(s2);
        }
        System.out.println("Added successful!");
    }
}
